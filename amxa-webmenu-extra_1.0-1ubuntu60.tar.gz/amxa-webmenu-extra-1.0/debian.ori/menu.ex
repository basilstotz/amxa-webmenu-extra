?package(amxa-webmenu-extra):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="amxa-webmenu-extra" command="/usr/bin/amxa-webmenu-extra"
