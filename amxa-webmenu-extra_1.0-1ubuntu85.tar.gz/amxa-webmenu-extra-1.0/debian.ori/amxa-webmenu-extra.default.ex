# Defaults for amxa-webmenu-extra initscript
# sourced by /etc/init.d/amxa-webmenu-extra
# installed at /etc/default/amxa-webmenu-extra by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
